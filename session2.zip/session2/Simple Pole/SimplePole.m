clc;
clear all;
close all;
%%
a = 10;

s = tf('s');
G =  (1)/(s+a);
step(G)
