clc;
clear all;
close all;
%%
a = 0;
b = 2;

s = tf('s');
G =  (1)/((s+a)*(s+b));

impulse(G)
