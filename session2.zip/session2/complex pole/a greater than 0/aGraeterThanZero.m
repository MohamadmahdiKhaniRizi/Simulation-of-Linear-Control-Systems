clc;
close all;
clear all;

%%
a = 5;
b = 2;
c = 6;
s = tf('s');
G = 1 / ((s+c)*(s + a + b*j)*(s+ a - b*j));

step(G)