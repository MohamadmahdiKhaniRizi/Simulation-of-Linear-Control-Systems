clc;
clear all;
close all;
%%
a = 20;
b = 2;
c = 4;

s = tf('s');
G =  (s^2 + c)/((s+a)*(s+b));

step(G)
