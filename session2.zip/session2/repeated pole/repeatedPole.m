clc;
clear all;
close all;
%%
a = 2;
b = 2;

s = tf('s');
G =  (1)/((s+a)*(s+b));

step(G)
